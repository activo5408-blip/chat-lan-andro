// Micrófono: medidor de nivel (barra vertical) junto al selector, volumen ajustable y
// aplicación del dispositivo/volumen elegidos a notas de voz y llamadas. Cargar ANTES de app.js.
(function () {
  "use strict";
  const md = navigator.mediaDevices;
  if (!md || !md.getUserMedia) return;
  const LS_GAIN = "chatlan.micGain";
  const AC = window.AudioContext || window.webkitAudioContext;
  const rawGUM = md.getUserMedia.bind(md);
  window.__rawGUM = rawGUM;

  // ---------------------------------------------------------------- volumen
  function loadGain() {
    try { const v = parseFloat(localStorage.getItem(LS_GAIN)); if (isFinite(v) && v >= 0 && v <= 2) return v; } catch (e) {}
    return 1;
  }
  let gain = loadGain();
  const liveNodes = new Set(); // GainNode de flujos ya procesados (ajuste en vivo)

  function chosenDevice() {
    try {
      const sel = document.getElementById("settingsAudioDevice");
      if (sel && sel.value) return sel.value;
      if (typeof userSettings !== "undefined" && userSettings && userSettings.audio_device) return userSettings.audio_device;
    } catch (e) {}
    return "";
  }

  async function processGain(raw) {
    try {
      if (!AC || !raw.getAudioTracks().length) return raw;
      const ctx = new AC();
      if (ctx.state === "suspended") await Promise.race([ctx.resume(), new Promise((r) => setTimeout(r, 600))]);
      if (ctx.state !== "running") { try { ctx.close(); } catch (e) {} return raw; }
      const src = ctx.createMediaStreamSource(new MediaStream(raw.getAudioTracks()));
      const g = ctx.createGain(); g.gain.value = gain;
      const lim = ctx.createDynamicsCompressor();      // limitador suave: evita saturar al subir el volumen
      lim.threshold.value = -3; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.003; lim.release.value = 0.1;
      const dst = ctx.createMediaStreamDestination();
      src.connect(g); g.connect(lim); lim.connect(dst);
      const outAudio = dst.stream.getAudioTracks()[0];
      const out = new MediaStream([outAudio].concat(raw.getVideoTracks()));
      const origStop = outAudio.stop.bind(outAudio);
      outAudio.stop = () => {
        origStop();
        raw.getTracks().forEach((t) => t.stop());
        liveNodes.delete(g);
        try { ctx.close(); } catch (e) {}
      };
      liveNodes.add(g);
      return out;
    } catch (e) { return raw; }
  }

  md.getUserMedia = async function (constraints) {
    let c = constraints;
    if (c && c.audio) {
      const dev = chosenDevice();
      if (dev) {
        const a = c.audio === true ? {} : Object.assign({}, c.audio);
        if (!a.deviceId) { a.deviceId = { ideal: dev }; c = Object.assign({}, c, { audio: a }); }
      }
    }
    const raw = await rawGUM(c);
    if (!c || !c.audio || Math.abs(gain - 1) < 0.01) return raw; // 100 %: sin procesar
    return processGain(raw);
  };

  // ---------------------------------------------------------------- UI en Ajustes
  const sel = document.getElementById("settingsAudioDevice");
  const view = document.getElementById("view-settings");
  if (!sel || !sel.parentElement || !view) return;

  const group = sel.parentElement;          // .settings-group con la etiqueta y el selector
  const row = document.createElement("div");
  row.className = "mic-row";
  group.insertBefore(row, sel);
  row.appendChild(sel);
  const meter = document.createElement("div");
  meter.className = "mic-meter"; meter.title = "Nivel del micrófono";
  meter.innerHTML = '<div class="mic-meter-fill" id="micMeterFill"></div>';
  row.appendChild(meter);
  const fill = meter.firstChild;
  const msg = document.createElement("div");
  msg.className = "mic-meter-msg"; msg.id = "micMeterMsg"; msg.textContent = "Habla para ver el nivel";
  group.appendChild(msg);

  const volGroup = document.createElement("div");
  volGroup.className = "settings-group";
  volGroup.innerHTML =
    '<label class="settings-label">Volumen del micrófono: <span id="micGainVal"></span>%</label>' +
    '<input type="range" id="micGainRange" min="0" max="200" step="5" class="settings-range" />' +
    '<div class="mic-meter-msg">Se aplica a notas de voz y llamadas (a partir de la siguiente).</div>';
  group.parentElement.insertBefore(volGroup, group.nextSibling);
  const range = volGroup.querySelector("#micGainRange"), val = volGroup.querySelector("#micGainVal");
  range.value = Math.round(gain * 100); val.textContent = range.value;
  range.addEventListener("input", () => {
    gain = parseInt(range.value, 10) / 100;
    val.textContent = range.value;
    try { localStorage.setItem(LS_GAIN, String(gain)); } catch (e) {}
    liveNodes.forEach((g) => { try { g.gain.value = gain; } catch (e) {} });
  });

  // ---------------------------------------------------------------- medidor
  let token = 0, mStream = null, mCtx = null, raf = 0, shown = 0;

  function stopMeter() {
    token++;
    if (raf) cancelAnimationFrame(raf); raf = 0;
    if (mStream) { mStream.getTracks().forEach((t) => t.stop()); mStream = null; }
    if (mCtx) { try { mCtx.close(); } catch (e) {} mCtx = null; }
    fill.style.clipPath = "inset(100% 0 0 0)"; shown = 0;
  }
  const viewActive = () => view.classList.contains("active");

  // nivel 0..1 a partir del RMS (escala dB de -60 a 0) incluyendo el volumen elegido
  window.__micLevel = (rms) => Math.max(0, Math.min(1, (20 * Math.log10(Math.max(rms * gain, 1e-5)) + 60) / 60));

  async function startMeter() {
    stopMeter();
    if (!AC || !viewActive()) return;
    const my = token;
    const dev = sel.value;
    let stream;
    try {
      const base = { echoCancellation: false, noiseSuppression: false, autoGainControl: false };
      try { stream = await rawGUM({ audio: dev ? Object.assign({ deviceId: { exact: dev } }, base) : base }); }
      catch (e) { if (!dev) throw e; stream = await rawGUM({ audio: base }); }  // dispositivo ya no existe
    } catch (e) {
      if (my === token) msg.textContent = "Sin acceso al micrófono (" + ((e && e.name) || e) + ")";
      return;
    }
    if (my !== token || !viewActive()) { stream.getTracks().forEach((t) => t.stop()); return; }
    msg.textContent = "Habla para ver el nivel";
    mStream = stream;
    mCtx = new AC();
    try { await mCtx.resume(); } catch (e) {}
    const an = mCtx.createAnalyser(); an.fftSize = 1024;
    mCtx.createMediaStreamSource(stream).connect(an);
    const buf = new Float32Array(an.fftSize);
    const loop = () => {
      if (my !== token) return;
      an.getFloatTimeDomainData(buf);
      let sum = 0; for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
      const lv = window.__micLevel(Math.sqrt(sum / buf.length));
      shown = Math.max(lv, shown * 0.88);       // subida inmediata, caída suave
      fill.style.clipPath = "inset(" + ((1 - shown) * 100).toFixed(1) + "% 0 0 0)";
      raf = requestAnimationFrame(loop);
    };
    loop();
  }

  new MutationObserver(() => { if (viewActive()) startMeter(); else stopMeter(); })
    .observe(view, { attributes: true, attributeFilter: ["class"] });
  sel.addEventListener("change", () => { if (viewActive()) startMeter(); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) stopMeter(); else if (viewActive()) startMeter(); });
  if (md.addEventListener) md.addEventListener("devicechange", () => { if (viewActive()) setTimeout(startMeter, 400); });
})();
